<?php


include ('config/dbcon.php');


function getAllActive($table){
    global $con;
    $query = "SELECT * FROM $table WHERE status = '0' ";
    $query_result = mysqli_query($con, $query);
    return $query_result;
}

function redirect($url,$message){
    $_SESSION['message'] = $message;
    header('location: '.$url);
    exit(0);
}   

function getIDActive($table, $id){
    global $con;
    $query = "SELECT * FROM $table WHERE id = '$id' AND status = '0' ";
    $query_result = mysqli_query($con, $query);
    return $query_result;
}

function getSlugActive($table, $slug){
    global $con;
    $query = "SELECT * FROM $table WHERE slug = '$slug' AND status = '0' LIMIT 1 ";
    $query_result = mysqli_query($con, $query);
    return $query_result;
}

function getProdByCategory($category_id){
    global $con;
    $query = "SELECT * FROM products WHERE category_id = '$category_id' AND status = '0'";
    $query_result = mysqli_query($con, $query);
    return $query_result;
}

?>