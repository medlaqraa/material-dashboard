<?php 
    session_start();
    include ('../config/dbcon.php');

    if(isset($_SESSION['auth']))
    {
        if(isset($_POST['scope']))
        {
            $scope = $_POST['scope'];
            switch($scope)
            {
                case "add":
                    $product_id = $_POST['product_id'];
                    $prod_qty = $_POST['prod_qty'];
                    
                    
                    $user_id = $_SESSION['auth_user']['user_id'];
                    $insert_query = "INSERT INTO carts (user_id, product_id, prod_qty) VALUES ('$user_id','$product_id','$prod_qty')";
                    $result = mysqli_query($conn, $insert_query);
                    if($result)
                    {
                        echo 201;
                    }
                    else
                    {
                        echo 500;
                    }
                    break;
                default:
                    echo 500;
            }
        }
    }
    else
    {
        echo 401;
    }
?>